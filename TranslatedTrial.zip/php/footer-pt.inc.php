<?php
    echo "<footer id='fh5co-footer' role='contentinfo'>
    <div class='container'>

        <div class='row copyright'>
            <div class='col-md-12 text-center'>
                <p>
                            <small class='block' ><span id='date'></span>. Todos os direitos reservados.</small>

                </p>
                <p>
                    <ul class='fh5co-social-icons'>
                        <li><a href='#'><i class='icon-twitter'></i></a></li>
                        <li><a href='#'><i class='icon-facebook'></i></a></li>
                        <li><a href='#'><i class='icon-linkedin'></i></a></li>
                        <li><a href='#'><i class='icon-dribbble'></i></a></li>
                    </ul>
                </p>
            </div>
        </div>

    </div>
</footer>";
?>